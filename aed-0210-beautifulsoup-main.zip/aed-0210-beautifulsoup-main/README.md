# Aula de 02/10 de Algoritmos e Estruturas de Dados I 

**Doc: https://www.crummy.com/software/BeautifulSoup/bs4/doc/**

O html usado: https://santodigital.com.br/

1. ` pip install beautifulsoup4 `
2.
````
Código no arquivo sumario.py
````
